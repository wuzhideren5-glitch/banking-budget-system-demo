import { useState, useEffect, useRef } from "react";
import { Download, Upload, ChevronRight, ChevronDown, TrendingUp, Calculator, AlertCircle, Save, Plus, Trash2, Search } from "lucide-react";
import {
  fetchDriverCategories,
  fetchDriverDataAccountOptions,
  downloadDriverTemplate,
  importDriverExcel,
  importDriverJson,
  saveDriverAccountMapping,
  deleteDriverAccountMapping,
  type DriverCategoryDto,
  type DriverIndicatorDto,
  type DriverImportRequestDto,
  type DriverImportResponseDto,
  type DriverDataAccountOptionDto,
} from "@/lib/api";

// ── Month labels ──
const MONTHS = [
  "M01", "M02", "M03", "M04", "M05", "M06",
  "M07", "M08", "M09", "M10", "M11", "M12",
];

const MONTH_LABELS = [
  "1月", "2月", "3月", "4月", "5月", "6月",
  "7月", "8月", "9月", "10月", "11月", "12月",
];

// ── Inline types for form state ──
type ProductInput = {
  product_code: string;
  product_name: string;
  data_acct_code: string | null;
  data_acct_name: string;
  value_type: string;
  report_code: string | null;
  report_path: string[];
  monthly: (number | null)[]; // length 12, null means unchanged
};

function parseReportToken(token: string): { code: string; name: string } {
  const trimmed = token.trim();
  const m = trimmed.match(/^([A-Z]\d+)\s+(.+)$/);
  if (!m) return { code: "", name: trimmed };
  return { code: m[1], name: m[2] };
}

function formatReportPath(path: string[]): string {
  if (!path.length) return "未映射数据科目";
  return path
    .map((token) => {
      const parsed = parseReportToken(token);
      return parsed.name || parsed.code || token;
    })
    .join(" / ");
}

export function BudgetPredictionContent() {
  const [categories, setCategories] = useState<DriverCategoryDto[]>([]);
  const [selectedIndicator, setSelectedIndicator] = useState<DriverIndicatorDto | null>(null);
  const [expandedCats, setExpandedCats] = useState<Set<string>>(new Set(["SCALE", "YIELD"]));
  const [expandedInds, setExpandedInds] = useState<Set<string>>(new Set());
  const [productInputs, setProductInputs] = useState<ProductInput[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<DriverImportResponseDto | null>(null);
  const [importing, setImporting] = useState(false);
  const [accountOptions, setAccountOptions] = useState<DriverDataAccountOptionDto[]>([]);
  const [accountSearch, setAccountSearch] = useState("");
  const [mappingProductCode, setMappingProductCode] = useState("");
  const [mappingDataAcctCode, setMappingDataAcctCode] = useState("");
  const [mappingSaving, setMappingSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load categories on mount
  useEffect(() => {
    loadCategories();
    void loadAccountOptions();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchDriverCategories();
      setCategories(data);
    } catch (e: any) {
      setError(e.message || "Failed to load driver categories");
    } finally {
      setLoading(false);
    }
  };

  const refreshCategoriesAndSelection = async (indicatorCode: string) => {
    const data = await fetchDriverCategories();
    setCategories(data);
    const refreshed = data.flatMap((c) => c.indicators).find((ind) => ind.indicator_code === indicatorCode) ?? null;
    setSelectedIndicator(refreshed);
  };

  const loadAccountOptions = async (q = "") => {
    const rows = await fetchDriverDataAccountOptions(q);
    setAccountOptions(rows);
  };

  // When indicator changes, init product inputs
  useEffect(() => {
    if (!selectedIndicator) {
      setProductInputs([]);
      setMappingProductCode("");
      return;
    }
    const ind = selectedIndicator;
    const firstProductCode = ind.products[0]?.product_code ?? "";
    setMappingProductCode((prev) =>
      prev && ind.products.some((p) => p.product_code === prev) ? prev : firstProductCode
    );
    setMappingDataAcctCode("");
    if (ind.has_product_detail && ind.products.length > 0) {
      const rows = ind.products.flatMap((p) => {
        const accounts = p.data_accounts ?? [];
        if (accounts.length === 0) {
          return [{
            product_code: p.product_code,
            product_name: p.product_name || p.product_code,
            data_acct_code: null,
            data_acct_name: "未配置",
            value_type: ind.value_type,
            report_code: null,
            report_path: ["未映射数据科目"],
            monthly: Array(12).fill(null),
          }];
        }
        return accounts.map((a) => ({
          product_code: p.product_code,
          product_name: p.product_name || p.product_code,
          data_acct_code: a.data_acct_code,
          data_acct_name: a.data_acct_name,
          value_type: a.value_type,
          report_code: a.report_code,
          report_path: a.report_path?.length ? a.report_path : ["未映射数据科目"],
          monthly: Array(12).fill(null),
        }));
      });
      setProductInputs(rows);
    } else {
      // Single "全行" input
      setProductInputs([
        {
          product_code: "",
          product_name: "全行",
          data_acct_code: selectedIndicator.data_acct_code,
          data_acct_name: selectedIndicator.data_acct_code || "未配置",
          value_type: selectedIndicator.value_type,
          report_code: null,
          report_path: ["未映射数据科目"],
          monthly: Array(12).fill(null),
        },
      ]);
    }
  }, [selectedIndicator]);

  useEffect(() => {
    const t = window.setTimeout(() => {
      void loadAccountOptions(accountSearch).catch((e: any) => setError(e.message || "加载数据科目失败"));
    }, 250);
    return () => window.clearTimeout(t);
  }, [accountSearch]);

  const toggleCat = (code: string) => {
    setExpandedCats((prev) => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  };

  const toggleInd = (code: string) => {
    setExpandedInds((prev) => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  };

  const selectIndicator = (ind: DriverIndicatorDto) => {
    setSelectedIndicator(ind);
    setImportResult(null);
    setError(null);
  };

  const updateMonthlyValue = (prodIdx: number, monthIdx: number, raw: string) => {
    const text = raw.trim();
    const v = parseFloat(text.replace(/,/g, ""));
    setProductInputs((prev) => {
      const next = [...prev];
      const p = { ...next[prodIdx] };
      p.monthly = [...p.monthly];
      p.monthly[monthIdx] = text === "" || isNaN(v) ? null : v;
      next[prodIdx] = p;
      return next;
    });
  };

  const fillAllMonths = (prodIdx: number, raw: string) => {
    const v = parseFloat(raw.replace(/,/g, ""));
    const val = isNaN(v) ? 0 : v;
    setProductInputs((prev) => {
      const next = [...prev];
      const p = { ...next[prodIdx], monthly: Array(12).fill(val) };
      next[prodIdx] = p;
      return next;
    });
  };

  // Build import request from inputs
  const buildImportRequest = (): DriverImportRequestDto[] => {
    if (!selectedIndicator) return [];
    const requests: DriverImportRequestDto[] = [];

    for (const pi of productInputs) {
      if (selectedIndicator.has_monthly_detail) {
        // Monthly detail: build M01-M12 items
        const items = pi.monthly.flatMap((v, i) => (
          v === null ? [] : [{ month: MONTHS[i], value: v }]
        ));
        if (items.length === 0) continue;
        requests.push({
          indicator_code: selectedIndicator.indicator_code,
          product_code: pi.product_code || null,
          data_acct_code: pi.data_acct_code,
          monthly_values: items,
        });
      } else {
        // Single annual value: only M01 contains the value
        const annualVal = pi.monthly[0];
        if (annualVal === null) continue;
        // For annual indicators, distribute: we store in M01
        requests.push({
          indicator_code: selectedIndicator.indicator_code,
          product_code: pi.product_code || null,
          data_acct_code: pi.data_acct_code,
          monthly_values: [{ month: "M01", value: annualVal }],
        });
      }
    }
    return requests;
  };

  const handleJsonImport = async (recalculate: boolean) => {
    const req = buildImportRequest();
    if (req.length === 0) {
      setError("No data to import");
      return;
    }
    setImporting(true);
    setError(null);
    try {
      const result = await importDriverJson(req, { recalculate });
      setImportResult(result);
    } catch (e: any) {
      setError(e.message || "Save failed");
    } finally {
      setImporting(false);
    }
  };

  const handleExcelImport = async (file: File) => {
    setImporting(true);
    setError(null);
    try {
      const result = await importDriverExcel(file);
      setImportResult(result);
    } catch (e: any) {
      setError(e.message || "Excel import failed");
    } finally {
      setImporting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleExcelImport(file);
  };

  const handleDownloadTemplate = async () => {
    try {
      await downloadDriverTemplate();
    } catch (e: any) {
      setError(e.message || "Download failed");
    }
  };

  const handleAddMapping = async () => {
    if (!selectedIndicator || !mappingProductCode || !mappingDataAcctCode) {
      setError("请选择产品和数据科目");
      return;
    }
    setMappingSaving(true);
    setError(null);
    try {
      await saveDriverAccountMapping({
        indicator_code: selectedIndicator.indicator_code,
        product_code: mappingProductCode,
        data_acct_code: mappingDataAcctCode,
        sort_order: productInputs.filter((p) => p.product_code === mappingProductCode && p.data_acct_code).length + 1,
      });
      await refreshCategoriesAndSelection(selectedIndicator.indicator_code);
      setMappingDataAcctCode("");
    } catch (e: any) {
      setError(e.message || "保存数据科目绑定失败");
    } finally {
      setMappingSaving(false);
    }
  };

  const handleDeleteMapping = async (pi: ProductInput) => {
    if (!selectedIndicator || !pi.product_code || !pi.data_acct_code) return;
    const ok = window.confirm(`确认删除 ${pi.product_name} 与 ${pi.data_acct_code} ${pi.data_acct_name} 的绑定？`);
    if (!ok) return;
    setMappingSaving(true);
    setError(null);
    try {
      await deleteDriverAccountMapping(selectedIndicator.indicator_code, pi.product_code, pi.data_acct_code);
      await refreshCategoriesAndSelection(selectedIndicator.indicator_code);
    } catch (e: any) {
      setError(e.message || "删除数据科目绑定失败");
    } finally {
      setMappingSaving(false);
    }
  };

  // ── Render helpers ──
  const showMonthly = selectedIndicator?.has_monthly_detail === 1;
  const showProducts = selectedIndicator?.has_product_detail === 1;

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-50">
        <div className="text-sm text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div className="h-full flex bg-white">
      {/* ── Left sidebar: Category tree ── */}
      <div className="w-60 border-r border-gray-200 overflow-y-auto bg-[#fafbfc] flex-shrink-0">
        <div className="px-3 py-2 border-b border-gray-200">
          <h3 className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
            驱动因素分类
          </h3>
        </div>
        {categories.length === 0 && !loading ? (
          <div className="p-4 text-xs text-gray-400">未加载到驱动数据</div>
        ) : (
          categories.map((cat) => {
            const isExpanded = expandedCats.has(cat.category_code);
            return (
              <div key={cat.category_code}>
                <div
                  className="flex items-center gap-1 px-2 py-1.5 cursor-pointer hover:bg-gray-100 text-xs font-medium text-gray-700"
                  onClick={() => toggleCat(cat.category_code)}
                >
                  {isExpanded ? (
                    <ChevronDown className="w-3 h-3 text-gray-400" />
                  ) : (
                    <ChevronRight className="w-3 h-3 text-gray-400" />
                  )}
                  {cat.category_name}
                </div>
                {isExpanded &&
                  cat.indicators.map((ind) => {
                    const isIndExpanded = expandedInds.has(ind.indicator_code);
                    const isSelected = selectedIndicator?.indicator_code === ind.indicator_code;
                    const hasProducts = ind.has_product_detail && ind.products.length > 0;
                    return (
                      <div key={ind.indicator_code}>
                        <div
                          className={`flex items-center gap-1 pl-5 pr-2 py-1 cursor-pointer text-xs ${
                            isSelected
                              ? "bg-blue-50 text-blue-700 font-medium"
                              : "text-gray-600 hover:bg-gray-100"
                          }`}
                          onClick={() => {
                            if (hasProducts) toggleInd(ind.indicator_code);
                            selectIndicator(ind);
                          }}
                        >
                          {hasProducts ? (
                            isIndExpanded ? (
                              <ChevronDown className="w-3 h-3 text-gray-400" />
                            ) : (
                              <ChevronRight className="w-3 h-3 text-gray-400" />
                            )
                          ) : (
                            <span className="w-3" />
                          )}
                          <span className="truncate">{ind.indicator_name}</span>
                          <span className="ml-auto text-[10px] text-gray-400">
                            {ind.value_type === "百分比" ? "%" : "¥"}
                          </span>
                        </div>
                        {isIndExpanded &&
                          ind.products.map((p) => (
                            <div
                              key={p.id}
                              className="flex items-center gap-1 pl-8 pr-2 py-1 text-[11px] text-gray-500 hover:bg-gray-100 cursor-pointer"
                              onClick={() => selectIndicator(ind)}
                            >
                              <span className="w-3" />
                              <span className="truncate">{p.product_name || p.product_code}</span>
                            </div>
                          ))}
                      </div>
                    );
                  })}
              </div>
            );
          })
        )}
      </div>

      {/* ── Main content ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-gray-200 bg-gray-50">
          <span className="text-xs font-medium text-gray-600">预算预测驱动</span>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1 px-3 py-1 text-xs border border-gray-300 rounded hover:bg-gray-100 text-gray-700"
            >
              <Download className="w-3 h-3" />
              下载模板
            </button>
            <label className="flex items-center gap-1 px-3 py-1 text-xs border border-blue-300 rounded bg-blue-50 hover:bg-blue-100 text-blue-700 cursor-pointer">
              <Upload className="w-3 h-3" />
              上传Excel导入
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xlsm"
                className="hidden"
                onChange={handleFileChange}
              />
            </label>
          </div>
        </div>

        {/* Error display */}
        {error && (
          <div className="mx-4 mt-2 flex items-center gap-1.5 px-3 py-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
            <AlertCircle className="w-3.5 h-3.5" />
            {error}
          </div>
        )}

        {/* Content area */}
        <div className="flex-1 overflow-auto p-4">
          {!selectedIndicator ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center text-gray-400">
                <Calculator className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p className="text-sm">请从左侧选择一个驱动指标</p>
                <p className="text-xs mt-1">选择后可输入动因参数并生成预算预测数据</p>
              </div>
            </div>
          ) : (
            <div>
              {/* Indicator header */}
              <div className="mb-4">
                <h3 className="text-sm font-semibold text-gray-800">
                  {selectedIndicator.indicator_name}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  类型：{selectedIndicator.value_type}
                  {selectedIndicator.data_acct_code && ` | 科目：${selectedIndicator.data_acct_code}`}
                  {showProducts && ` | 产品级明细`}
                  {!showMonthly && ` | 全年度一次性输入`}
                </p>
              </div>

              {showProducts && (
                <div className="mb-3 border border-gray-200 rounded bg-gray-50 px-3 py-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-gray-700">数据科目绑定维护</span>
                    <select
                      value={mappingProductCode}
                      onChange={(e) => setMappingProductCode(e.target.value)}
                      className="h-7 w-44 border border-gray-300 rounded bg-white px-2 text-xs"
                    >
                      {selectedIndicator.products.map((p) => (
                        <option key={p.product_code} value={p.product_code}>
                          {p.product_code} {p.product_name || ""}
                        </option>
                      ))}
                    </select>
                    <div className="relative w-72">
                      <Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        value={accountSearch}
                        onChange={(e) => setAccountSearch(e.target.value)}
                        placeholder="搜索数据科目编码/名称"
                        className="h-7 w-full pl-7 pr-2 border border-gray-300 rounded bg-white text-xs"
                      />
                    </div>
                    <select
                      value={mappingDataAcctCode}
                      onChange={(e) => setMappingDataAcctCode(e.target.value)}
                      className="h-7 flex-1 min-w-[260px] border border-gray-300 rounded bg-white px-2 text-xs"
                    >
                      <option value="">请选择数据科目</option>
                      {accountOptions.map((a) => (
                        <option key={a.data_acct_code} value={a.data_acct_code}>
                          {a.data_acct_code} {a.data_acct_name}（{a.value_type}）
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      disabled={mappingSaving || !mappingProductCode || !mappingDataAcctCode}
                      onClick={() => void handleAddMapping()}
                      className="h-7 flex items-center gap-1 px-3 text-xs rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      绑定
                    </button>
                  </div>
                </div>
              )}

              {/* Input form */}
              <div className="overflow-x-auto">
                <table className="border-collapse text-xs">
                  <thead>
                    <tr className="bg-blue-50">
                      <th className="sticky left-0 bg-blue-50 border border-gray-300 px-3 py-1.5 text-left font-medium text-gray-700 min-w-[120px]">
                        报告科目
                      </th>
                      <th className="border border-gray-300 px-3 py-1.5 text-left font-medium text-gray-700 min-w-[240px]">
                        数据科目
                      </th>
                      <th className="border border-gray-300 px-3 py-1.5 text-left font-medium text-gray-700 min-w-[120px]">
                        {showProducts ? "产品" : "范围"}
                      </th>
                      <th className="border border-gray-300 px-3 py-1.5 text-left font-medium text-gray-700 min-w-[72px]">
                        数值类型
                      </th>
                      <th className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-700 min-w-[60px]">
                        维护
                      </th>
                      {showMonthly ? (
                        MONTH_LABELS.map((ml) => (
                          <th
                            key={ml}
                            className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-700 min-w-[72px]"
                          >
                            {ml}
                          </th>
                        ))
                      ) : (
                        <th className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-700 min-w-[120px]">
                          年度值
                        </th>
                      )}
                      <th className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-600 bg-blue-50 min-w-[60px]">
                        填充
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {productInputs.map((pi, piIdx) => (
                      <tr key={piIdx} className="hover:bg-gray-50">
                        <td className="sticky left-0 bg-white border border-gray-300 px-3 py-1 text-gray-700">
                          <div className="max-w-[280px] whitespace-normal leading-5">
                            {formatReportPath(pi.report_path)}
                          </div>
                        </td>
                        <td className="border border-gray-300 px-3 py-1 text-gray-700">
                          {pi.data_acct_code ? (
                            <>
                              <span className="font-mono text-[11px] text-gray-500">{pi.data_acct_code}</span>
                              <span className="ml-1">{pi.data_acct_name}</span>
                            </>
                          ) : (
                            <span className="text-gray-400">未配置</span>
                          )}
                        </td>
                        <td className="border border-gray-300 px-3 py-1 font-medium text-gray-700">
                          <span className="font-mono text-[11px] text-gray-500">{pi.product_code}</span>
                          <span className="ml-1">{pi.product_name}</span>
                        </td>
                        <td className="border border-gray-300 px-3 py-1 text-gray-600">
                          {pi.value_type}
                        </td>
                        <td className="border border-gray-300 px-1 py-1 text-center">
                          {pi.data_acct_code ? (
                            <button
                              type="button"
                              disabled={mappingSaving}
                              onClick={() => void handleDeleteMapping(pi)}
                              className="inline-flex items-center justify-center w-6 h-6 rounded hover:bg-red-50 disabled:opacity-50"
                              title="删除绑定"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-500" />
                            </button>
                          ) : (
                            <span className="text-gray-300">-</span>
                          )}
                        </td>
                        {showMonthly
                          ? MONTHS.map((_, mi) => (
                              <td key={mi} className="border border-gray-300 p-0">
                                <input
                                  type="text"
                                  className="w-full px-2 py-1 text-xs text-right border-0 focus:outline-none focus:ring-1 focus:ring-blue-400 bg-transparent"
                                  value={pi.monthly[mi] ?? ""}
                                  onChange={(e) => updateMonthlyValue(piIdx, mi, e.target.value)}
                                  placeholder="0"
                                />
                              </td>
                            ))
                          : (
                              <td className="border border-gray-300 p-0">
                                <input
                                  type="text"
                                  className="w-full px-2 py-1 text-xs text-right border-0 focus:outline-none focus:ring-1 focus:ring-blue-400 bg-transparent"
                                  value={pi.monthly[0] ?? ""}
                                  onChange={(e) => {
                                    const text = e.target.value.trim();
                                    const v = parseFloat(text.replace(/,/g, ""));
                                    setProductInputs((prev) => {
                                      const next = [...prev];
                                      const p = { ...next[piIdx] };
                                      p.monthly = [text === "" || isNaN(v) ? null : v, ...Array(11).fill(null)];
                                      next[piIdx] = p;
                                      return next;
                                    });
                                  }}
                                  placeholder="0"
                                />
                              </td>
                            )}
                        <td className="border border-gray-300 p-0">
                          {showMonthly && (
                            <input
                              type="text"
                              className="w-full px-2 py-1 text-xs text-center border-0 focus:outline-none focus:ring-1 focus:ring-blue-400 bg-transparent text-gray-400"
                              onChange={(e) => fillAllMonths(piIdx, e.target.value)}
                              placeholder="..."
                            />
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Submit button */}
              <div className="mt-4 flex items-center gap-3">
                <button
                  onClick={() => handleJsonImport(false)}
                  disabled={importing}
                  className={`flex items-center gap-1.5 px-4 py-1.5 text-xs rounded font-medium ${
                    importing
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                      : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
                  }`}
                >
                  <Save className="w-3.5 h-3.5" />
                  {importing ? "正在保存..." : "保存"}
                </button>
                <button
                  onClick={() => handleJsonImport(true)}
                  disabled={importing}
                  className={`flex items-center gap-1.5 px-4 py-1.5 text-xs rounded font-medium ${
                    importing
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                      : "bg-blue-600 text-white hover:bg-blue-700"
                  }`}
                >
                  <Calculator className="w-3.5 h-3.5" />
                  {importing ? "正在保存并重算..." : "保存并重算"}
                </button>
                <span className="text-xs text-gray-400">
                  保存后可在预算基础数据维护按产品查看；重算会同步刷新公式结果
                </span>
              </div>

              {/* Import result */}
              {importResult && (
                <div className="mt-4 border border-gray-200 rounded">
                  <div className="px-3 py-2 bg-gray-50 border-b border-gray-200">
                    <h4 className="text-xs font-semibold text-gray-700">导入结果</h4>
                  </div>
                  <div className="p-3 space-y-2">
                    <div className="flex gap-4 text-xs text-gray-600">
                      <span>版本ID: {importResult.version_id}</span>
                      <span>预算年度: {importResult.budget_year}</span>
                      <span>保存单元格: {importResult.saved_cells}</span>
                    </div>

                    {importResult.errors && importResult.errors.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-red-600 mb-1">错误:</p>
                        {importResult.errors.map((err, i) => (
                          <p key={i} className="text-xs text-red-500">- {err}</p>
                        ))}
                      </div>
                    )}

                    {importResult.monthly && importResult.monthly.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-gray-700 mb-1">月度计算结果:</p>
                        <div className="overflow-x-auto">
                          <table className="border-collapse text-xs">
                            <thead>
                              <tr className="bg-gray-100">
                                <th className="border border-gray-300 px-2 py-1 text-left">月份</th>
                                {Object.keys(importResult.monthly[0] || {}).filter(k => k !== "month").map((k) => (
                                  <th key={k} className="border border-gray-300 px-2 py-1 text-right">{k}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {importResult.monthly.map((row: any, idx: number) => (
                                <tr key={idx} className="hover:bg-gray-50">
                                  <td className="border border-gray-300 px-2 py-1 font-medium">{row.month}</td>
                                  {Object.keys(row).filter(k => k !== "month").map((k) => (
                                    <td key={k} className="border border-gray-300 px-2 py-1 text-right">
                                      {typeof row[k] === "number" ? row[k].toLocaleString(undefined, { maximumFractionDigits: 2 }) : String(row[k])}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
