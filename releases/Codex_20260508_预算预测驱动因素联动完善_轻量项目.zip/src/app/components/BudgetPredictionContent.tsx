import { useState, useEffect, useRef } from "react";
import { Download, Upload, ChevronRight, ChevronDown, TrendingUp, Calculator, AlertCircle, Save } from "lucide-react";
import {
  fetchDriverCategories,
  downloadDriverTemplate,
  importDriverExcel,
  importDriverJson,
  type DriverCategoryDto,
  type DriverIndicatorDto,
  type DriverImportRequestDto,
  type DriverImportResponseDto,
  type DriverMappedDataAccountDto,
} from "@/lib/api";

// ── Month labels ──
const MONTHS = [
  "M01", "M02", "M03", "M04", "M05", "M06",
  "M07", "M08", "M09", "M10", "M11", "M12",
];

const MONTH_LABELS = [
  "1月", "2月", "3月", "4月", "5月", "6月",
  "7月", "8月", "9月", "10月", "11月", "12月",
];

// ── Inline types for form state ──
type ProductInput = {
  product_code: string;
  product_name: string;
  data_accounts: DriverMappedDataAccountDto[];
  monthly: (number | null)[]; // length 12, null means unchanged
};

export function BudgetPredictionContent() {
  const [categories, setCategories] = useState<DriverCategoryDto[]>([]);
  const [selectedIndicator, setSelectedIndicator] = useState<DriverIndicatorDto | null>(null);
  const [expandedCats, setExpandedCats] = useState<Set<string>>(new Set(["SCALE", "YIELD"]));
  const [expandedInds, setExpandedInds] = useState<Set<string>>(new Set());
  const [productInputs, setProductInputs] = useState<ProductInput[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<DriverImportResponseDto | null>(null);
  const [importing, setImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load categories on mount
  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchDriverCategories();
      setCategories(data);
    } catch (e: any) {
      setError(e.message || "Failed to load driver categories");
    } finally {
      setLoading(false);
    }
  };

  // When indicator changes, init product inputs
  useEffect(() => {
    if (!selectedIndicator) {
      setProductInputs([]);
      return;
    }
    const ind = selectedIndicator;
    if (ind.has_product_detail && ind.products.length > 0) {
      setProductInputs(
        ind.products.map((p) => ({
          product_code: p.product_code,
          product_name: p.product_name || p.product_code,
          data_accounts: p.data_accounts ?? [],
          monthly: Array(12).fill(null),
        }))
      );
    } else {
      // Single "全行" input
      setProductInputs([
        {
          product_code: "",
          product_name: "全行",
          data_accounts: [],
          monthly: Array(12).fill(null),
        },
      ]);
    }
  }, [selectedIndicator]);

  const toggleCat = (code: string) => {
    setExpandedCats((prev) => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  };

  const toggleInd = (code: string) => {
    setExpandedInds((prev) => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  };

  const selectIndicator = (ind: DriverIndicatorDto) => {
    setSelectedIndicator(ind);
    setImportResult(null);
    setError(null);
  };

  const updateMonthlyValue = (prodIdx: number, monthIdx: number, raw: string) => {
    const text = raw.trim();
    const v = parseFloat(text.replace(/,/g, ""));
    setProductInputs((prev) => {
      const next = [...prev];
      const p = { ...next[prodIdx] };
      p.monthly = [...p.monthly];
      p.monthly[monthIdx] = text === "" || isNaN(v) ? null : v;
      next[prodIdx] = p;
      return next;
    });
  };

  const fillAllMonths = (prodIdx: number, raw: string) => {
    const v = parseFloat(raw.replace(/,/g, ""));
    const val = isNaN(v) ? 0 : v;
    setProductInputs((prev) => {
      const next = [...prev];
      const p = { ...next[prodIdx], monthly: Array(12).fill(val) };
      next[prodIdx] = p;
      return next;
    });
  };

  // Build import request from inputs
  const buildImportRequest = (): DriverImportRequestDto[] => {
    if (!selectedIndicator) return [];
    const requests: DriverImportRequestDto[] = [];

    for (const pi of productInputs) {
      if (selectedIndicator.has_monthly_detail) {
        // Monthly detail: build M01-M12 items
        const items = pi.monthly.flatMap((v, i) => (
          v === null ? [] : [{ month: MONTHS[i], value: v }]
        ));
        if (items.length === 0) continue;
        requests.push({
          indicator_code: selectedIndicator.indicator_code,
          product_code: pi.product_code || null,
          monthly_values: items,
        });
      } else {
        // Single annual value: only M01 contains the value
        const annualVal = pi.monthly[0];
        if (annualVal === null) continue;
        // For annual indicators, distribute: we store in M01
        requests.push({
          indicator_code: selectedIndicator.indicator_code,
          product_code: pi.product_code || null,
          monthly_values: [{ month: "M01", value: annualVal }],
        });
      }
    }
    return requests;
  };

  const handleJsonImport = async (recalculate: boolean) => {
    const req = buildImportRequest();
    if (req.length === 0) {
      setError("No data to import");
      return;
    }
    setImporting(true);
    setError(null);
    try {
      const result = await importDriverJson(req, { recalculate });
      setImportResult(result);
    } catch (e: any) {
      setError(e.message || "Save failed");
    } finally {
      setImporting(false);
    }
  };

  const handleExcelImport = async (file: File) => {
    setImporting(true);
    setError(null);
    try {
      const result = await importDriverExcel(file);
      setImportResult(result);
    } catch (e: any) {
      setError(e.message || "Excel import failed");
    } finally {
      setImporting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleExcelImport(file);
  };

  const handleDownloadTemplate = async () => {
    try {
      await downloadDriverTemplate();
    } catch (e: any) {
      setError(e.message || "Download failed");
    }
  };

  // ── Render helpers ──
  const showMonthly = selectedIndicator?.has_monthly_detail === 1;
  const showProducts = selectedIndicator?.has_product_detail === 1;

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-50">
        <div className="text-sm text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div className="h-full flex bg-white">
      {/* ── Left sidebar: Category tree ── */}
      <div className="w-60 border-r border-gray-200 overflow-y-auto bg-[#fafbfc] flex-shrink-0">
        <div className="px-3 py-2 border-b border-gray-200">
          <h3 className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
            驱动因素分类
          </h3>
        </div>
        {categories.length === 0 && !loading ? (
          <div className="p-4 text-xs text-gray-400">未加载到驱动数据</div>
        ) : (
          categories.map((cat) => {
            const isExpanded = expandedCats.has(cat.category_code);
            return (
              <div key={cat.category_code}>
                <div
                  className="flex items-center gap-1 px-2 py-1.5 cursor-pointer hover:bg-gray-100 text-xs font-medium text-gray-700"
                  onClick={() => toggleCat(cat.category_code)}
                >
                  {isExpanded ? (
                    <ChevronDown className="w-3 h-3 text-gray-400" />
                  ) : (
                    <ChevronRight className="w-3 h-3 text-gray-400" />
                  )}
                  {cat.category_name}
                </div>
                {isExpanded &&
                  cat.indicators.map((ind) => {
                    const isIndExpanded = expandedInds.has(ind.indicator_code);
                    const isSelected = selectedIndicator?.indicator_code === ind.indicator_code;
                    const hasProducts = ind.has_product_detail && ind.products.length > 0;
                    return (
                      <div key={ind.indicator_code}>
                        <div
                          className={`flex items-center gap-1 pl-5 pr-2 py-1 cursor-pointer text-xs ${
                            isSelected
                              ? "bg-blue-50 text-blue-700 font-medium"
                              : "text-gray-600 hover:bg-gray-100"
                          }`}
                          onClick={() => {
                            if (hasProducts) toggleInd(ind.indicator_code);
                            selectIndicator(ind);
                          }}
                        >
                          {hasProducts ? (
                            isIndExpanded ? (
                              <ChevronDown className="w-3 h-3 text-gray-400" />
                            ) : (
                              <ChevronRight className="w-3 h-3 text-gray-400" />
                            )
                          ) : (
                            <span className="w-3" />
                          )}
                          <span className="truncate">{ind.indicator_name}</span>
                          <span className="ml-auto text-[10px] text-gray-400">
                            {ind.value_type === "百分比" ? "%" : "¥"}
                          </span>
                        </div>
                        {isIndExpanded &&
                          ind.products.map((p) => (
                            <div
                              key={p.id}
                              className="flex items-center gap-1 pl-8 pr-2 py-1 text-[11px] text-gray-500 hover:bg-gray-100 cursor-pointer"
                              onClick={() => selectIndicator(ind)}
                            >
                              <span className="w-3" />
                              <span className="truncate">{p.product_name || p.product_code}</span>
                            </div>
                          ))}
                      </div>
                    );
                  })}
              </div>
            );
          })
        )}
      </div>

      {/* ── Main content ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-gray-200 bg-gray-50">
          <span className="text-xs font-medium text-gray-600">预算预测驱动</span>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1 px-3 py-1 text-xs border border-gray-300 rounded hover:bg-gray-100 text-gray-700"
            >
              <Download className="w-3 h-3" />
              下载模板
            </button>
            <label className="flex items-center gap-1 px-3 py-1 text-xs border border-blue-300 rounded bg-blue-50 hover:bg-blue-100 text-blue-700 cursor-pointer">
              <Upload className="w-3 h-3" />
              上传Excel导入
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xlsm"
                className="hidden"
                onChange={handleFileChange}
              />
            </label>
          </div>
        </div>

        {/* Error display */}
        {error && (
          <div className="mx-4 mt-2 flex items-center gap-1.5 px-3 py-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
            <AlertCircle className="w-3.5 h-3.5" />
            {error}
          </div>
        )}

        {/* Content area */}
        <div className="flex-1 overflow-auto p-4">
          {!selectedIndicator ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center text-gray-400">
                <Calculator className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p className="text-sm">请从左侧选择一个驱动指标</p>
                <p className="text-xs mt-1">选择后可输入动因参数并生成预算预测数据</p>
              </div>
            </div>
          ) : (
            <div>
              {/* Indicator header */}
              <div className="mb-4">
                <h3 className="text-sm font-semibold text-gray-800">
                  {selectedIndicator.indicator_name}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  类型：{selectedIndicator.value_type}
                  {selectedIndicator.data_acct_code && ` | 科目：${selectedIndicator.data_acct_code}`}
                  {showProducts && ` | 产品级明细`}
                  {!showMonthly && ` | 全年度一次性输入`}
                </p>
              </div>

              {/* Input form */}
              <div className="overflow-x-auto">
                <table className="border-collapse text-xs">
                  <thead>
                    <tr className="bg-blue-50">
                      <th className="sticky left-0 bg-blue-50 border border-gray-300 px-3 py-1.5 text-left font-medium text-gray-700 min-w-[120px]">
                        {showProducts ? "产品" : "范围"}
                      </th>
                      <th className="border border-gray-300 px-3 py-1.5 text-left font-medium text-gray-700 min-w-[260px]">
                        联动数据科目
                      </th>
                      {showMonthly ? (
                        MONTH_LABELS.map((ml) => (
                          <th
                            key={ml}
                            className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-700 min-w-[72px]"
                          >
                            {ml}
                          </th>
                        ))
                      ) : (
                        <th className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-700 min-w-[120px]">
                          年度值
                        </th>
                      )}
                      <th className="border border-gray-300 px-2 py-1.5 text-center font-medium text-gray-600 bg-blue-50 min-w-[60px]">
                        填充
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {productInputs.map((pi, piIdx) => (
                      <tr key={piIdx} className="hover:bg-gray-50">
                        <td className="sticky left-0 bg-white border border-gray-300 px-3 py-1 font-medium text-gray-700">
                          {pi.product_name}
                        </td>
                        <td className="border border-gray-300 px-3 py-1 text-gray-600">
                          {pi.data_accounts.length > 0 ? (
                            <div className="space-y-0.5">
                              {pi.data_accounts.map((a) => (
                                <div key={a.data_acct_code} className="whitespace-nowrap">
                                  <span className="font-mono text-[11px] text-gray-500">{a.data_acct_code}</span>
                                  <span className="ml-1">{a.data_acct_name}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-gray-400">未配置</span>
                          )}
                        </td>
                        {showMonthly
                          ? MONTHS.map((_, mi) => (
                              <td key={mi} className="border border-gray-300 p-0">
                                <input
                                  type="text"
                                  className="w-full px-2 py-1 text-xs text-right border-0 focus:outline-none focus:ring-1 focus:ring-blue-400 bg-transparent"
                                  value={pi.monthly[mi] ?? ""}
                                  onChange={(e) => updateMonthlyValue(piIdx, mi, e.target.value)}
                                  placeholder="0"
                                />
                              </td>
                            ))
                          : (
                              <td className="border border-gray-300 p-0">
                                <input
                                  type="text"
                                  className="w-full px-2 py-1 text-xs text-right border-0 focus:outline-none focus:ring-1 focus:ring-blue-400 bg-transparent"
                                  value={pi.monthly[0] ?? ""}
                                  onChange={(e) => {
                                    const text = e.target.value.trim();
                                    const v = parseFloat(text.replace(/,/g, ""));
                                    setProductInputs((prev) => {
                                      const next = [...prev];
                                      const p = { ...next[piIdx] };
                                      p.monthly = [text === "" || isNaN(v) ? null : v, ...Array(11).fill(null)];
                                      next[piIdx] = p;
                                      return next;
                                    });
                                  }}
                                  placeholder="0"
                                />
                              </td>
                            )}
                        <td className="border border-gray-300 p-0">
                          {showMonthly && (
                            <input
                              type="text"
                              className="w-full px-2 py-1 text-xs text-center border-0 focus:outline-none focus:ring-1 focus:ring-blue-400 bg-transparent text-gray-400"
                              onChange={(e) => fillAllMonths(piIdx, e.target.value)}
                              placeholder="..."
                            />
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Submit button */}
              <div className="mt-4 flex items-center gap-3">
                <button
                  onClick={() => handleJsonImport(false)}
                  disabled={importing}
                  className={`flex items-center gap-1.5 px-4 py-1.5 text-xs rounded font-medium ${
                    importing
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                      : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
                  }`}
                >
                  <Save className="w-3.5 h-3.5" />
                  {importing ? "正在保存..." : "保存"}
                </button>
                <button
                  onClick={() => handleJsonImport(true)}
                  disabled={importing}
                  className={`flex items-center gap-1.5 px-4 py-1.5 text-xs rounded font-medium ${
                    importing
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                      : "bg-blue-600 text-white hover:bg-blue-700"
                  }`}
                >
                  <Calculator className="w-3.5 h-3.5" />
                  {importing ? "正在保存并重算..." : "保存并重算"}
                </button>
                <span className="text-xs text-gray-400">
                  保存后可在预算基础数据维护按产品查看；重算会同步刷新公式结果
                </span>
              </div>

              {/* Import result */}
              {importResult && (
                <div className="mt-4 border border-gray-200 rounded">
                  <div className="px-3 py-2 bg-gray-50 border-b border-gray-200">
                    <h4 className="text-xs font-semibold text-gray-700">导入结果</h4>
                  </div>
                  <div className="p-3 space-y-2">
                    <div className="flex gap-4 text-xs text-gray-600">
                      <span>版本ID: {importResult.version_id}</span>
                      <span>预算年度: {importResult.budget_year}</span>
                      <span>保存单元格: {importResult.saved_cells}</span>
                    </div>

                    {importResult.errors && importResult.errors.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-red-600 mb-1">错误:</p>
                        {importResult.errors.map((err, i) => (
                          <p key={i} className="text-xs text-red-500">- {err}</p>
                        ))}
                      </div>
                    )}

                    {importResult.monthly && importResult.monthly.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-gray-700 mb-1">月度计算结果:</p>
                        <div className="overflow-x-auto">
                          <table className="border-collapse text-xs">
                            <thead>
                              <tr className="bg-gray-100">
                                <th className="border border-gray-300 px-2 py-1 text-left">月份</th>
                                {Object.keys(importResult.monthly[0] || {}).filter(k => k !== "month").map((k) => (
                                  <th key={k} className="border border-gray-300 px-2 py-1 text-right">{k}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {importResult.monthly.map((row: any, idx: number) => (
                                <tr key={idx} className="hover:bg-gray-50">
                                  <td className="border border-gray-300 px-2 py-1 font-medium">{row.month}</td>
                                  {Object.keys(row).filter(k => k !== "month").map((k) => (
                                    <td key={k} className="border border-gray-300 px-2 py-1 text-right">
                                      {typeof row[k] === "number" ? row[k].toLocaleString(undefined, { maximumFractionDigits: 2 }) : String(row[k])}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
