"""预算预测驱动参数模块：驱动因素分类/指标管理、Excel 模板下载与导入计算。"""
from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any, Awaitable, Callable

import aiosqlite
from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.db_paths import common_db_path
from app.formula_refs import extract_formula_codes
from app.schemas import (
    DriverCategoryTree,
    DriverImportMonthlyItem,
    DriverImportRequest,
    DriverImportResponse,
    DriverIndicatorTree,
    DriverMappedDataAccount,
    DriverProductRow,
)


HEADER_FILL = PatternFill(start_color="FF4472C4", end_color="FF4472C4", fill_type="solid")
HEADER_FONT = Font(name="微软雅黑", size=10, bold=True, color="FFFFFFFF")
BODY_FONT = Font(name="微软雅黑", size=9)


def _iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_percentage_for_storage(raw: Any, is_pct_type: bool) -> float:
    """将 Excel 单元格值转为存储值；百分比类型除以 100 后存储。"""
    if raw is None:
        return 0.0
    if isinstance(raw, str):
        s = raw.strip().replace(",", "").replace("，", "").replace("%", "")
        if not s:
            return 0.0
        try:
            return float(s) / 100.0 if is_pct_type else float(s)
        except ValueError:
            return 0.0
    if isinstance(raw, (int, float)):
        v = float(raw)
        return v / 100.0 if is_pct_type else v
    return 0.0


def _match_indicator_from_name(sheet_name: str, name_cell: str, all_indicators: list[dict]) -> dict | None:
    """按指标名匹配 driver_indicator。"""
    n = name_cell.strip()
    for ind in all_indicators:
        if ind["indicator_name"] == n or ind["indicator_code"] == n:
            return ind
    return None


def _match_product_from_name(name_cell: str, all_products: list[dict]) -> str | None:
    """按产品名或代码匹配 product_code，'全行'返回空字符串（不限定产品）。"""
    n = name_cell.strip()
    if not n or n in ("全行", "公司级", "全部"):
        return ""  # 公司级/全行
    for p in all_products:
        if p["product_code"] == n or p["product_name"] == n:
            return p["product_code"]
    # 模糊匹配：产品名包含输入词
    for p in all_products:
        if n in (p["product_name"] or ""):
            return p["product_code"]
    return None


def _month_to_period_id(period_month_map: dict[int, int]) -> dict[int, int]:
    """Convert shared pid->month map into month->pid for driver imports."""
    return {month: period_id for period_id, month in period_month_map.items()}


def _mapping_key(indicator_code: str, product_code: str | None) -> tuple[str, str]:
    return (indicator_code.strip().upper(), (product_code or "").strip().upper())


def _resolve_data_acct_codes(
    indicator: dict,
    product_code: str | None,
    account_mappings: dict[tuple[str, str], list[str]],
) -> list[str]:
    codes = account_mappings.get(_mapping_key(str(indicator["indicator_code"]), product_code))
    if codes:
        return codes
    fallback = str(indicator.get("data_acct_code") or "").strip().upper()
    return [fallback] if fallback else []


def _generate_excel_template(categories: list[dict], indicators: list[dict], products: list[dict]) -> BytesIO:
    """动态生成驱动参数 Excel 模板。"""
    wb = Workbook()
    wb.remove(wb.active)

    # 构建 indicator_lookup: indicator_code → indicator dict
    ind_by_code = {i["indicator_code"]: i for i in indicators}
    # 构建 products for indicator: 每个有产品拆分的指标对应哪些产品
    prod_by_indicator: dict[str, list[dict]] = {}
    for i in indicators:
        if i["has_product_detail"]:
            prod_by_indicator[i["indicator_code"]] = [
                p for p in products if p.get("indicator_code") == i["indicator_code"]
            ]
            if not prod_by_indicator[i["indicator_code"]]:
                prod_by_indicator[i["indicator_code"]] = products  # fallback all

    for cat in sorted(categories, key=lambda x: x["sort_order"]):
        ws = wb.create_sheet(title=cat["category_name"])
        cat_indicators = [i for i in indicators if i["category_code"] == cat["category_code"]]

        # Header
        headers = ["指标名称", "产品"] + [f"M{m:02d}" for m in range(1, 13)]
        for ci, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=ci, value=h)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.alignment = Alignment(horizontal="center")

        row = 2
        for ind in sorted(cat_indicators, key=lambda x: x["sort_order"]):
            if ind["has_product_detail"]:
                prods = prod_by_indicator.get(ind["indicator_code"], products)
                for p in sorted(prods, key=lambda x: x.get("product_code", "")):
                    ws.cell(row=row, column=1, value=ind["indicator_name"]).font = BODY_FONT
                    ws.cell(row=row, column=2, value=p.get("product_name", p.get("product_code", ""))).font = BODY_FONT
                    row += 1
            else:
                ws.cell(row=row, column=1, value=ind["indicator_name"]).font = BODY_FONT
                ws.cell(row=row, column=2, value="全行").font = BODY_FONT
                row += 1

        # Auto-width
        ws.column_dimensions["A"].width = 22
        ws.column_dimensions["B"].width = 22
        for m in range(1, 13):
            ws.column_dimensions[get_column_letter(m + 2)].width = 12

    out = BytesIO()
    wb.save(out)
    out.seek(0)
    return out


def build_budget_driver_router(
    *,
    editable_context_provider: Callable[[], Awaitable[tuple[Path, int, int]]],
    recalculate_product_formula_rows: Callable[..., Awaitable[int]],
    rebuild_budget_summary: Callable[[int, Path], Awaitable[int]],
    get_year_period_months: Callable[[int], Awaitable[dict[int, int]]],
    write_operation_log: Callable[..., Awaitable[None]],
) -> APIRouter:
    router = APIRouter()

    # ── GET 驱动分类树 ──
    @router.get("/api/driver/categories", response_model=list[DriverCategoryTree])
    async def list_driver_categories():
        common_path = common_db_path()
        async with aiosqlite.connect(common_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")

            # categories
            cur = await db.execute(
                "SELECT category_code, category_name, sort_order FROM driver_category ORDER BY sort_order"
            )
            cat_rows = await cur.fetchall()

            # indicators
            cur = await db.execute(
                "SELECT indicator_code, category_code, indicator_name, value_type, data_acct_code, has_product_detail, has_monthly_detail, sort_order FROM driver_indicator ORDER BY sort_order, indicator_code"
            )
            ind_rows = await cur.fetchall()

            # products (with product_type name)
            cur = await db.execute(
                """
                SELECT dp.id, dp.indicator_code, dp.product_code, pt.product_name, dp.sort_order
                FROM driver_product dp
                LEFT JOIN product_type pt ON pt.product_code = dp.product_code
                ORDER BY dp.indicator_code, dp.sort_order, dp.product_code
                """
            )
            prod_rows = await cur.fetchall()

            cur = await db.execute(
                "SELECT DISTINCT indicator_code, product_code FROM driver_account_mapping"
            )
            mapped_products: dict[str, set[str]] = {}
            for indicator_code, product_code in await cur.fetchall():
                mapped_products.setdefault(str(indicator_code), set()).add(str(product_code))

            cur = await db.execute(
                """
                SELECT dam.indicator_code, dam.product_code, dam.data_acct_code,
                       da.data_acct_name, da.value_type, dam.sort_order
                FROM driver_account_mapping dam
                JOIN data_account da ON da.data_acct_code = dam.data_acct_code
                ORDER BY dam.indicator_code, dam.product_code, dam.sort_order, dam.data_acct_code
                """
            )
            mapped_accounts: dict[tuple[str, str], list[dict]] = {}
            for r in await cur.fetchall():
                mapped_accounts.setdefault((str(r[0]), str(r[1])), []).append({
                    "data_acct_code": str(r[2]),
                    "data_acct_name": str(r[3]),
                    "value_type": str(r[4]),
                    "sort_order": int(r[5] or 0),
                })

        # build tree
        ind_by_cat: dict[str, list[dict]] = {}
        for r in ind_rows:
            ind_by_cat.setdefault(r[1], []).append({
                "indicator_code": r[0], "category_code": r[1], "indicator_name": r[2],
                "value_type": r[3], "data_acct_code": r[4], "has_product_detail": r[5],
                "has_monthly_detail": r[6], "sort_order": r[7],
            })

        prod_by_ind: dict[str, list[dict]] = {}
        for r in prod_rows:
            mapped_for_indicator = mapped_products.get(str(r[1]))
            if mapped_for_indicator is not None and str(r[2]) not in mapped_for_indicator:
                continue
            prod_by_ind.setdefault(r[1], []).append({
                "id": r[0], "indicator_code": r[1], "product_code": r[2],
                "product_name": r[3], "sort_order": r[4],
                "data_accounts": mapped_accounts.get((str(r[1]), str(r[2])), []),
            })

        result = []
        for r in cat_rows:
            indicators = []
            for ind in ind_by_cat.get(r[0], []):
                indicators.append(DriverIndicatorTree(
                    indicator_code=ind["indicator_code"],
                    indicator_name=ind["indicator_name"],
                    value_type=ind["value_type"],
                    data_acct_code=ind.get("data_acct_code"),
                    has_product_detail=ind["has_product_detail"],
                    has_monthly_detail=ind["has_monthly_detail"],
                    sort_order=ind["sort_order"],
                    products=[
                        DriverProductRow(
                            id=p["id"], indicator_code=p["indicator_code"],
                            product_code=p["product_code"], product_name=p.get("product_name"),
                            sort_order=p["sort_order"],
                            data_accounts=[
                                DriverMappedDataAccount(
                                    data_acct_code=a["data_acct_code"],
                                    data_acct_name=a["data_acct_name"],
                                    value_type=a["value_type"],
                                    sort_order=a["sort_order"],
                                )
                                for a in p.get("data_accounts", [])
                            ],
                        )
                        for p in prod_by_ind.get(ind["indicator_code"], [])
                    ],
                ))
            result.append(DriverCategoryTree(
                category_code=r[0], category_name=r[1], sort_order=r[2],
                indicators=indicators,
            ))

        return result

    # ── GET 模板下载 ──
    @router.get("/api/driver/template")
    async def download_driver_template():
        budget_path, budget_year, version_id = await editable_context_provider()
        common_path = common_db_path()

        async with aiosqlite.connect(common_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            cur = await db.execute(
                "SELECT category_code, category_name, sort_order FROM driver_category ORDER BY sort_order"
            )
            categories = [{"category_code": r[0], "category_name": r[1], "sort_order": r[2]}
                          for r in await cur.fetchall()]

            cur = await db.execute(
                "SELECT indicator_code, category_code, indicator_name, value_type, data_acct_code, has_product_detail, has_monthly_detail, sort_order FROM driver_indicator ORDER BY sort_order"
            )
            indicators = [{
                "indicator_code": r[0], "category_code": r[1], "indicator_name": r[2],
                "value_type": r[3], "data_acct_code": r[4], "has_product_detail": r[5],
                "has_monthly_detail": r[6], "sort_order": r[7],
            } for r in await cur.fetchall()]

            cur = await db.execute(
                """
                SELECT dp.indicator_code, dp.product_code, pt.product_name
                FROM driver_product dp
                JOIN product_type pt ON pt.product_code = dp.product_code
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM driver_account_mapping dam_any
                    WHERE dam_any.indicator_code = dp.indicator_code
                )
                OR EXISTS (
                    SELECT 1
                    FROM driver_account_mapping dam
                    WHERE dam.indicator_code = dp.indicator_code
                      AND dam.product_code = dp.product_code
                )
                ORDER BY dp.indicator_code, dp.sort_order, dp.product_code
                """
            )
            products = [{"indicator_code": r[0], "product_code": r[1], "product_name": r[2]}
                        for r in await cur.fetchall()]

        stream = await asyncio.to_thread(_generate_excel_template, categories, indicators, products)
        return StreamingResponse(
            stream,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=driver_prediction_temp.xlsx"},
        )

    # ── POST 导入预览 ──
    @router.post("/api/driver/preview")
    async def preview_driver_import(file: UploadFile = File(...)):
        content = await file.read()
        try:
            wb = await asyncio.to_thread(lambda: __import__("openpyxl").load_workbook(filename=BytesIO(content), data_only=True))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"无法读取 Excel 文件：{exc}")

        preview_rows: list[dict] = []
        total_rows = 0
        for ws in wb.worksheets:
            if ws.max_row < 2:
                continue
            headers = [str(ws.cell(1, c).value or "") for c in range(1, ws.max_column + 1)]
            for ridx in range(2, min(ws.max_row + 1, 22)):  # preview first 20 data rows
                row_vals = {}
                for ci, h in enumerate(headers):
                    if h:
                        row_vals[h] = str(ws.cell(ridx, ci + 1).value or "")
                if any(v.strip() for v in row_vals.values()):
                    preview_rows.append({"工作表": ws.title, **row_vals})
            total_rows += max(0, ws.max_row - 1)

        return {"columns": ["工作表"] + [h for h in (wb.worksheets[0].max_column > 0 and [str(wb.worksheets[0].cell(1, c).value or "") for c in range(1, wb.worksheets[0].max_column + 1)] or [])], "preview_rows": preview_rows, "row_count": total_rows}

    # ── POST 导入计算 ──
    @router.post("/api/driver/import", response_model=DriverImportResponse)
    async def import_driver_data(file: UploadFile = File(...)):
        if not file.filename or not str(file.filename).lower().endswith((".xlsx", ".xlsm")):
            raise HTTPException(status_code=400, detail="请上传 .xlsx 或 .xlsm 文件")

        raw = await file.read()
        if len(raw) > 15 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="文件过大（上限 15MB）")

        budget_path, budget_year, version_id = await editable_context_provider()
        common_path = common_db_path()

        # Load config data
        async with aiosqlite.connect(common_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            cur = await db.execute(
                "SELECT indicator_code, indicator_name, value_type, data_acct_code, category_code, has_product_detail FROM driver_indicator ORDER BY indicator_code"
            )
            all_indicators = [{"indicator_code": r[0], "indicator_name": r[1], "value_type": r[2],
                               "data_acct_code": r[3], "category_code": r[4],
                               "has_product_detail": int(r[5] or 0)} for r in await cur.fetchall()]

            cur = await db.execute("SELECT product_code, product_name FROM product_type ORDER BY product_code")
            all_products = [{"product_code": r[0], "product_name": r[1]} for r in await cur.fetchall()]

            cur = await db.execute(
                "SELECT data_acct_code, value_type, budget_formula FROM data_account ORDER BY data_acct_code"
            )
            data_accounts = {str(r[0]): {"value_type": r[1], "budget_formula": r[2]} for r in await cur.fetchall()}

            cur = await db.execute(
                """
                SELECT indicator_code, product_code, data_acct_code
                FROM driver_account_mapping
                ORDER BY indicator_code, product_code, sort_order, data_acct_code
                """
            )
            account_mappings: dict[tuple[str, str], list[str]] = {}
            for r in await cur.fetchall():
                account_mappings.setdefault(_mapping_key(str(r[0]), str(r[1])), []).append(str(r[2]).strip().upper())

        # Map indicator names to indicator dict for matching
        ind_by_name: dict[str, dict] = {}
        ind_by_code: dict[str, dict] = {}
        for ind in all_indicators:
            ind_by_name[ind["indicator_name"]] = ind
            ind_by_code[ind["indicator_code"]] = ind

        # Period map: month index → period_id
        month_to_period = _month_to_period_id(await get_year_period_months(budget_year))

        errors: list[str] = []
        saved_cells = 0
        affected_products: set[str] = set()
        written_data_accts: set[str] = set()

        # Parse Excel
        try:
            wb = await asyncio.to_thread(lambda: __import__("openpyxl").load_workbook(filename=BytesIO(raw), data_only=True))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"无法读取 Excel：{exc}")

        # Process each sheet
        for ws in wb.worksheets:
            if ws.max_row < 2:
                continue
            # Read headers to find month columns
            header_row = [str(ws.cell(1, c).value or "").strip() for c in range(1, min(ws.max_column + 1, 20))]
            month_cols: dict[int, int] = {}  # col_index → month_index (1-12)
            for ci, h in enumerate(header_row):
                m = re.match(r"M(\d{2})", h)
                if m:
                    month_cols[ci] = int(m.group(1))

            # Process each data row
            async with aiosqlite.connect(budget_path) as bdb:
                await bdb.execute("PRAGMA foreign_keys = ON")
                now = _iso_now()

                for ridx in range(2, ws.max_row + 1):
                    name_cell = str(ws.cell(ridx, 1).value or "").strip()
                    product_cell = str(ws.cell(ridx, 2).value or "").strip()

                    if not name_cell:
                        continue

                    # Match indicator
                    indicator = ind_by_name.get(name_cell) or ind_by_code.get(name_cell)
                    if not indicator:
                        continue  # skip unknown indicators

                    # Determine product_code
                    product_code = _match_product_from_name(product_cell, all_products)
                    if product_code is None and indicator["has_product_detail"]:
                        errors.append(f"行 {ridx}: 未找到产品 '{product_cell}'")
                        continue
                    if not indicator["has_product_detail"]:
                        product_code = ""

                    data_acct_codes = _resolve_data_acct_codes(indicator, product_code, account_mappings)
                    if not data_acct_codes:
                        errors.append(f"行 {ridx}: 指标 {indicator['indicator_name']} 产品 {product_code or '全行'} 未绑定数据科目")
                        continue

                    is_pct = indicator["value_type"] == "百分比"

                    for ci, mi in month_cols.items():
                        raw_val = ws.cell(ridx, ci + 1).value
                        if raw_val is None:
                            continue
                        val = _parse_percentage_for_storage(raw_val, is_pct)

                        # Map month to period_id
                        period_id = month_to_period.get(mi)
                        if not period_id:
                            continue

                        for data_acct_code in data_acct_codes:
                            await bdb.execute(
                                """
                                INSERT INTO budget_data (
                                    data_acct_code, product_code, period_id, budget_actual,
                                    version_id, value, need_calc, create_time, update_time
                                ) VALUES (?, ?, ?, 0, ?, ?, 0, ?, ?)
                                ON CONFLICT(data_acct_code, product_code, period_id, version_id, budget_actual)
                                DO UPDATE SET value = excluded.value, need_calc = 0, update_time = excluded.update_time
                                """,
                                (data_acct_code, product_code, period_id, version_id, val, now, now),
                            )
                            saved_cells += 1
                            written_data_accts.add(data_acct_code)

                    if product_code:
                        affected_products.add(product_code)

                await bdb.commit()

        # Recalculate formulas for affected products
        for pc in sorted(affected_products):
            await recalculate_product_formula_rows(
                pc, version_id, 0,
                budget_path=budget_path, budget_year=budget_year,
            )

        # Rebuild budget_summary
        summary_rows = await rebuild_budget_summary(version_id, budget_path)

        # Compute summary: query key data accounts from budget_summary
        summary = {
            "version_id": version_id,
            "budget_year": budget_year,
            "saved_cells": saved_cells,
            "rebuilt_summary_rows": summary_rows,
            "affected_products": sorted(affected_products),
        }

        # Build simple monthly summary
        async with aiosqlite.connect(common_path) as cdb:
            await cdb.execute("PRAGMA foreign_keys = ON")
            cur = await cdb.execute("""
                SELECT data_acct_code, data_acct_name, value_type, budget_formula, actual_formula
                FROM data_account ORDER BY data_acct_code
            """)
            all_das = {str(r[0]): {"name": r[1], "value_type": r[2], "budget_formula": r[3], "actual_formula": r[4]}
                       for r in await cur.fetchall()}
            formula_data_accts = {
                code for code, info in all_das.items()
                if extract_formula_codes(str(info.get("budget_formula") or "")) & written_data_accts
            }

        monthly = []
        async with aiosqlite.connect(budget_path) as bdb:
            await bdb.execute("PRAGMA foreign_keys = ON")
            for mi in range(1, 13):
                month_label = f"M{mi:02d}"
                period_id = month_to_period.get(mi)
                if not period_id:
                    continue
                cur = await bdb.execute(
                    """
                    SELECT bd.data_acct_code, SUM(bd.value) as total
                    FROM budget_data bd
                    WHERE bd.version_id = ? AND bd.budget_actual = 0 AND bd.period_id = ?
                      AND (
                        bd.data_acct_code IN ({})
                        OR (bd.product_code IN ({}) AND bd.data_acct_code IN ({}))
                      )
                    GROUP BY bd.data_acct_code
                    ORDER BY bd.data_acct_code
                    """.format(
                        ",".join(["?"] * len(written_data_accts)) if written_data_accts else "''",
                        ",".join(["?"] * len(affected_products)) if affected_products else "''",
                        ",".join(["?"] * len(formula_data_accts)) if formula_data_accts else "''",
                    ),
                    (
                        version_id,
                        period_id,
                        *sorted(written_data_accts),
                        *sorted(affected_products),
                        *sorted(formula_data_accts),
                    ),
                )
                row_data = {"month": month_label}
                for r in await cur.fetchall():
                    code = str(r[0])
                    da_info = all_das.get(code, {})
                    name = da_info.get("name", code)
                    row_data[name] = round(float(r[1] or 0), 2)
                monthly.append(row_data)

        await write_operation_log(
            action_type="IMPORT",
            action_desc=f"驱动预测试算导入，写入 {saved_cells} 个单元格",
            target_table="budget_data",
            affected_rows=saved_cells,
            after_data={"version_id": version_id, "budget_year": budget_year, "saved_cells": saved_cells},
        )

        return DriverImportResponse(
            version_id=version_id,
            budget_year=budget_year,
            saved_cells=saved_cells,
            summary=summary,
            monthly=monthly,
            errors=errors,
        )

    # ── POST 直接 JSON 导入（用于测试）──
    @router.post("/api/driver/import-json", response_model=DriverImportResponse)
    async def import_driver_json(
        body: list[DriverImportRequest],
        recalculate: bool = Query(True),
    ):
        budget_path, budget_year, version_id = await editable_context_provider()
        common_path = common_db_path()

        month_to_period = _month_to_period_id(await get_year_period_months(budget_year))
        saved_cells = 0
        affected_products: set[str] = set()
        written_data_accts: set[str] = set()
        errors: list[str] = []

        async with aiosqlite.connect(common_path) as cdb:
            await cdb.execute("PRAGMA foreign_keys = ON")
            cur = await cdb.execute(
                "SELECT indicator_code, value_type, data_acct_code FROM driver_indicator"
            )
            ind_map = {str(r[0]): {"indicator_code": str(r[0]), "value_type": r[1], "data_acct_code": r[2]}
                       for r in await cur.fetchall()}

            cur = await cdb.execute(
                """
                SELECT indicator_code, product_code, data_acct_code
                FROM driver_account_mapping
                ORDER BY indicator_code, product_code, sort_order, data_acct_code
                """
            )
            account_mappings: dict[tuple[str, str], list[str]] = {}
            for r in await cur.fetchall():
                account_mappings.setdefault(_mapping_key(str(r[0]), str(r[1])), []).append(str(r[2]).strip().upper())

        async with aiosqlite.connect(budget_path) as bdb:
            await bdb.execute("PRAGMA foreign_keys = ON")
            now = _iso_now()

            for item in body:
                ind_info = ind_map.get(item.indicator_code)
                if not ind_info:
                    errors.append(f"未知指标: {item.indicator_code}")
                    continue

                is_pct = ind_info["value_type"] == "百分比"
                product_code = (item.product_code or "").strip().upper()
                data_acct_codes = _resolve_data_acct_codes(ind_info, product_code, account_mappings)
                if not data_acct_codes:
                    errors.append(f"指标 {item.indicator_code} 产品 {product_code or '全行'} 未绑定数据科目")
                    continue

                for mv in item.monthly_values:
                    mi = int(mv.month.replace("M", "").lstrip("0") or "1")
                    period_id = month_to_period.get(mi)
                    if not period_id:
                        continue

                    val = mv.value / 100.0 if is_pct else mv.value

                    for data_acct_code in data_acct_codes:
                        await bdb.execute(
                            """
                            INSERT INTO budget_data (
                                data_acct_code, product_code, period_id, budget_actual,
                                version_id, value, need_calc, create_time, update_time
                            ) VALUES (?, ?, ?, 0, ?, ?, 0, ?, ?)
                            ON CONFLICT(data_acct_code, product_code, period_id, version_id, budget_actual)
                            DO UPDATE SET value = excluded.value, need_calc = 0, update_time = excluded.update_time
                            """,
                            (data_acct_code, product_code, period_id, version_id, val, now, now),
                        )
                        saved_cells += 1
                        written_data_accts.add(data_acct_code)

                if product_code:
                    affected_products.add(product_code)

            await bdb.commit()

        summary_rows = 0
        if recalculate:
            for pc in sorted(affected_products):
                await recalculate_product_formula_rows(
                    pc, version_id, 0,
                    budget_path=budget_path, budget_year=budget_year,
                )
            summary_rows = await rebuild_budget_summary(version_id, budget_path)

        async with aiosqlite.connect(common_path) as cdb:
            await cdb.execute("PRAGMA foreign_keys = ON")
            cur = await cdb.execute("""
                SELECT data_acct_code, data_acct_name, value_type, budget_formula
                FROM data_account ORDER BY data_acct_code
            """)
            data_account_meta = {
                str(r[0]): {"name": str(r[1]), "value_type": str(r[2]), "budget_formula": r[3]}
                for r in await cur.fetchall()
            }
            formula_data_accts = {
                code for code, info in data_account_meta.items()
                if extract_formula_codes(str(info.get("budget_formula") or "")) & written_data_accts
            }

        # Monthly summary
        async with aiosqlite.connect(budget_path) as bdb:
            await bdb.execute("PRAGMA foreign_keys = ON")
            monthly = []
            for mi in range(1, 13):
                period_id = month_to_period.get(mi)
                if not period_id:
                    continue
                cur = await bdb.execute(
                    """
                    SELECT bd.data_acct_code, bd.value
                    FROM budget_data bd
                    WHERE bd.version_id = ? AND bd.budget_actual = 0 AND bd.period_id = ?
                      AND (
                        bd.data_acct_code IN ({})
                        OR (bd.product_code IN ({}) AND bd.data_acct_code IN ({}))
                      )
                    ORDER BY bd.data_acct_code
                    """.format(
                        ",".join(["?"] * len(written_data_accts)) if written_data_accts else "''",
                        ",".join(["?"] * len(affected_products)) if affected_products else "''",
                        ",".join(["?"] * len(formula_data_accts)) if formula_data_accts else "''",
                    ),
                    (
                        version_id,
                        period_id,
                        *sorted(written_data_accts),
                        *sorted(affected_products),
                        *sorted(formula_data_accts),
                    ),
                )
                row_data = {"month": f"M{mi:02d}"}
                for r in await cur.fetchall():
                    code = str(r[0])
                    name = data_account_meta.get(code, {}).get("name", code)
                    row_data[str(name)] = float(r[1] or 0)
                monthly.append(row_data)

        await write_operation_log(
            action_type="IMPORT",
            action_desc=f"驱动预测保存{'并重算' if recalculate else ''}，写入 {saved_cells} 个单元格",
            target_table="budget_data",
            affected_rows=saved_cells,
            after_data={"version_id": version_id, "budget_year": budget_year, "saved_cells": saved_cells},
        )

        return DriverImportResponse(
            version_id=version_id,
            budget_year=budget_year,
            saved_cells=saved_cells,
            summary={
                "rebuilt_summary_rows": summary_rows,
                "affected_products": sorted(affected_products),
                "recalculated": recalculate,
                "written_data_accts": sorted(written_data_accts),
            },
            monthly=monthly,
            errors=errors,
        )

    return router
