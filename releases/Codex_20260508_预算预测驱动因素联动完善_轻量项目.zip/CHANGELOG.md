# 银行预算管理系统 — 变更日志 (CHANGELOG)

> 本文档由 AI Release Manager 自动维护。  
> 格式规范见 `.claude/skills/merge-release/SKILL.md` 阶段四。

---

## v2.1 (2026-05-06) — 产品多层与Excel导入改造

### 变更来源
- ZLC: 20 项变更

### 变更明细
- 新增: `product_codes TEXT` 字段替代 `applies_to_all_products` 布尔值，支持"全部产品 / 公司级 / 指定多产品"三类语义
- 新增: `ProductType.parent_code`、`ProductType.level` 字段，支持产品科目多层树形结构
- 新增: `ProductMultiSelectDialog.tsx` 分层多选产品弹窗，支持父级展开到叶子节点
- 新增: Excel 导入"新增/更新"与"覆盖"两种模式（upsert/replace）
- 修改: 产品编码规则从 `Z+4位` 放宽为 `Z+4~8位`，兼容层级编码
- 修改: 数据科目 CRUD 全链路适配 `product_codes`
- 修改: 预算数据导入结果区分新增/覆盖/失败统计
- 移除: `data_account.applies_to_all_products` 字段及关联 CHECK 约束

### 已知待解决问题
- product_type 表的 `parent_code`/`level` 列通过 ALTER TABLE 补充，尚未纳入 `init_db.py` 新建表 DDL（待下一轮固化）
- `dept_product_mapping` 仍强制一产品一部门约束，多部门对应一产品的需求待专项改造
- `budget_summary` 重建仍使用 `dept_by_product` 字典，多部门场景下仅最后一个部门生效

### 风险评估
- 高风险: 4 项（核心数据模型变更，影响公式引擎、预算汇总、导入导出链路）
- 中风险: 4 项
- 低风险: 2 项

### PDD 更新
- System PDD: 新增 §0.7 本轮需求变更（2026-05-06）— ZLC
- Database PDD: 新增 §0.2 本轮同步说明（2026-05-06）— ZLC
- Files.md: ZLC 已追加 2026-05-06 更新摘要

### 数据库迁移
- `data_account`: `ALTER TABLE ADD COLUMN product_codes TEXT`，数据已从 `applies_to_all_products` + `product_code` 迁移
- `product_type`: `ALTER TABLE ADD COLUMN parent_code TEXT`，`ALTER TABLE ADD COLUMN level INTEGER DEFAULT 1`

---

---

## v2.0 (2026-04-29) — PDD 文档体系建立与项目初始化

### 变更来源
- 项目初始化阶段，未按团队成员拆分

### 变更明细
- 新增: 完整 PDD 文档体系 (System/Database/Agent/Rules/ERD/Files)
- 新增: FastAPI 后端 + Vite React 前端项目骨架
- 新增: 三库架构 (common.db / budget_{year}.db / compare.db)
- 新增: LangGraph Agent 智能体框架
- 新增: 飞书机器人 WebSocket 通道
- 新增: Excel 导入导出功能
- 新增: 公式引擎与预算汇总预聚合
- 新增: 多版本管理与多年度对比透视
- 新增: RLBA 用户权限体系

### 风险评估
- 高风险: 0 项（初始化阶段）
- 中风险: 0 项
- 低风险: 0 项

### PDD 更新
- System PDD: v1.0 初始版本
- Database PDD: v2.0 初始版本
- Agent PDD: 初始版本
- Rules PDD: 初始版本
- Files.md: 初始版本

---
