from __future__ import annotations

from typing import Awaitable, Callable

from fastapi import APIRouter, File, Form, UploadFile
from fastapi.responses import FileResponse

from app.schemas import (
    SmartReportCalcMetricRow,
    SmartReportCalcMetricUpsert,
    SmartReportGenerateRequest,
    SmartReportGenerateResponse,
    SmartReportInstanceRow,
    SmartReportPreviewRequest,
    SmartReportPreviewResponse,
    SmartReportTemplateCreateResponse,
    SmartReportTemplateRow,
    SmartReportTextTemplateCreate,
    SmartReportTemplateVariableRow,
    SmartReportTemplateVariableUpsert,
)
from app.services.smart_report_service import SmartReportService


def build_smart_reports_router(
    *,
    service: SmartReportService,
    write_operation_log: Callable[..., Awaitable[None]],
) -> APIRouter:
    router = APIRouter(prefix="/api/smart-reports", tags=["smart-reports"])

    @router.get("/templates", response_model=list[SmartReportTemplateRow])
    async def list_templates():
        return await service.list_templates()

    @router.post("/templates", response_model=SmartReportTemplateCreateResponse)
    async def upload_template(
        file: UploadFile = File(...),
        template_code: str = Form(...),
        template_name: str = Form(...),
        template_type: str = Form("analysis"),
        remark: str | None = Form(None),
    ):
        result = await service.create_or_update_template(
            file=file,
            template_code=template_code,
            template_name=template_name,
            template_type=template_type,
            remark=remark,
        )
        await write_operation_log(
            action_type="smart_report_template_upload",
            action_desc=f"上传智能报告模板：{result.template.template_code}",
            target_table="smart_report_template",
            affected_rows=1,
            after_data=result.model_dump(),
        )
        return result

    @router.post("/templates/text", response_model=SmartReportTemplateCreateResponse)
    async def create_text_template(body: SmartReportTextTemplateCreate):
        result = await service.create_or_update_text_template(
            template_code=body.template_code,
            template_name=body.template_name,
            content=body.content,
            template_type=body.template_type,
            remark=body.remark,
        )
        await write_operation_log(
            action_type="smart_report_template_text_create",
            action_desc=f"保存手工录入智能报告模板：{result.template.template_code}",
            target_table="smart_report_template",
            affected_rows=1,
            after_data=result.model_dump(),
        )
        return result

    @router.get("/templates/{template_id}", response_model=SmartReportTemplateRow)
    async def get_template(template_id: int):
        return await service.get_template(template_id)

    @router.get("/templates/{template_id}/variables", response_model=list[SmartReportTemplateVariableRow])
    async def list_variables(template_id: int):
        return await service.list_variables(template_id)

    @router.put("/templates/{template_id}/variables", response_model=list[SmartReportTemplateVariableRow])
    async def upsert_variables(template_id: int, variables: list[SmartReportTemplateVariableUpsert]):
        result = await service.upsert_variables(template_id, variables)
        await write_operation_log(
            action_type="smart_report_variable_upsert",
            action_desc=f"更新智能报告模板变量：template_id={template_id}",
            target_table="smart_report_template_variable",
            affected_rows=len(variables),
            after_data=[item.model_dump() for item in result],
        )
        return result

    @router.get("/calc-metrics", response_model=list[SmartReportCalcMetricRow])
    async def list_calc_metrics():
        return await service.list_calc_metrics()

    @router.put("/calc-metrics/{metric_code}", response_model=SmartReportCalcMetricRow)
    async def upsert_calc_metric(metric_code: str, body: SmartReportCalcMetricUpsert):
        body.metric_code = metric_code
        result = await service.upsert_calc_metric(body)
        await write_operation_log(
            action_type="smart_report_calc_metric_upsert",
            action_desc=f"保存智能报告计算指标：{result.metric_code}",
            target_table="smart_report_calc_metric",
            affected_rows=1,
            after_data=result.model_dump(),
        )
        return result

    @router.post("/generate", response_model=SmartReportGenerateResponse)
    async def generate_report(body: SmartReportGenerateRequest):
        result = await service.generate(body)
        await write_operation_log(
            action_type="smart_report_generate",
            action_desc=f"生成智能 Word 报告：instance_id={result.instance_id}",
            target_table="smart_report_instance",
            affected_rows=1,
            after_data=result.model_dump(),
        )
        return result

    @router.post("/preview", response_model=SmartReportPreviewResponse)
    async def preview_report(body: SmartReportPreviewRequest):
        return await service.preview(body)

    @router.get("/instances", response_model=list[SmartReportInstanceRow])
    async def list_instances():
        return await service.list_instances()

    @router.post("/instances/{instance_id}/refresh", response_model=SmartReportGenerateResponse)
    async def refresh_instance(instance_id: int):
        result = await service.refresh_instance(instance_id)
        await write_operation_log(
            action_type="smart_report_refresh",
            action_desc=f"刷新智能 Word 报告：instance_id={instance_id}",
            target_table="smart_report_instance",
            affected_rows=1,
            after_data=result.model_dump(),
        )
        return result

    @router.get("/instances/{instance_id}/download")
    async def download_instance(instance_id: int):
        path = await service.instance_output_path(instance_id)
        return FileResponse(
            path=str(path),
            filename=path.name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )

    return router
