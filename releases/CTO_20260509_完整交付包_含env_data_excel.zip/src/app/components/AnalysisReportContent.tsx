import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  Download,
  FileText,
  Loader2,
  RefreshCw,
  Save,
  Search,
  Upload,
  Wand2,
} from "lucide-react";
import {
  apiGet,
  apiPost,
  apiPostForm,
  apiPut,
  downloadFile,
  type SmartReportGenerateResponseDto,
  type SmartReportInstanceDto,
  type SmartReportTemplateCreateResponseDto,
  type SmartReportTemplateDto,
  type SmartReportTextTemplateCreateDto,
  type SmartReportTemplateVariableDto,
  type SmartReportTemplateVariableUpsertDto,
  type SmartReportVariableTypeDto,
} from "@/lib/api";

const VARIABLE_TYPE_LABEL: Record<SmartReportVariableTypeDto, string> = {
  metric: "指标",
  parameter: "参数",
  text: "文本",
  table: "表格",
  chart: "图表",
  analysis: "分析结论",
};

const VARIABLE_TYPES: SmartReportVariableTypeDto[] = ["metric", "parameter", "text", "table", "chart", "analysis"];

function fmtTime(value?: string | null): string {
  if (!value) return "-";
  return value.replace("T", " ").replace("Z", "");
}

function paramKeyOf(variable: SmartReportTemplateVariableDto): string {
  const raw = variable.binding_config?.param_key;
  if (typeof raw === "string" && raw.trim()) return raw.trim();
  return variable.variable_key.includes(":") ? variable.variable_key.split(":").slice(1).join(":") : variable.variable_key;
}

function textKeyOf(variable: SmartReportTemplateVariableDto): string {
  const raw = variable.binding_config?.text_key;
  if (typeof raw === "string" && raw.trim()) return raw.trim();
  return variable.variable_key.includes(":") ? variable.variable_key.split(":").slice(1).join(":") : variable.variable_key;
}

function bindingConfigFor(variableKey: string, variableType: SmartReportVariableTypeDto): Record<string, unknown> {
  const key = variableKey.includes(":") ? variableKey.split(":").slice(1).join(":").trim() : variableKey.trim();
  if (variableType === "metric") return { metric_id: key };
  if (variableType === "parameter") return { param_key: key };
  if (variableType === "text") return { text_key: key };
  return { [`${variableType}_id`]: key };
}

export function AnalysisReportContent() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [templates, setTemplates] = useState<SmartReportTemplateDto[]>([]);
  const [instances, setInstances] = useState<SmartReportInstanceDto[]>([]);
  const [variables, setVariables] = useState<SmartReportTemplateVariableDto[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | null>(null);
  const [searchText, setSearchText] = useState("");
  const [templateCode, setTemplateCode] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [templateInputMode, setTemplateInputMode] = useState<"upload" | "text">("upload");
  const [templateContent, setTemplateContent] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [savingVariables, setSavingVariables] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [refreshingInstanceId, setRefreshingInstanceId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [variableDrafts, setVariableDrafts] = useState<Record<string, SmartReportTemplateVariableUpsertDto>>({});
  const [paramValues, setParamValues] = useState<Record<string, string>>({
    year: "2026",
    month: "1",
    version_id: "1",
    budget_actual: "1",
  });
  const [textValues, setTextValues] = useState<Record<string, string>>({});
  const [lastGenerated, setLastGenerated] = useState<SmartReportGenerateResponseDto | null>(null);

  const selectedTemplate = templates.find((item) => item.template_id === selectedTemplateId) ?? null;

  const filteredTemplates = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return templates;
    return templates.filter(
      (item) =>
        item.template_code.toLowerCase().includes(q) ||
        item.template_name.toLowerCase().includes(q) ||
        (item.remark ?? "").toLowerCase().includes(q),
    );
  }, [searchText, templates]);

  const parameterVariables = variables.filter((item) => item.variable_type === "parameter");
  const textVariables = variables.filter((item) => item.variable_type === "text");
  const metricVariables = variables.filter((item) => item.variable_type === "metric");

  const loadTemplates = async (keepSelected = true) => {
    const rows = await apiGet<SmartReportTemplateDto[]>("/api/smart-reports/templates");
    setTemplates(rows);
    setSelectedTemplateId((current) => {
      if (keepSelected && current && rows.some((item) => item.template_id === current)) return current;
      return rows[0]?.template_id ?? null;
    });
  };

  const loadInstances = async () => {
    const rows = await apiGet<SmartReportInstanceDto[]>("/api/smart-reports/instances");
    setInstances(rows);
  };

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    Promise.all([loadTemplates(false), loadInstances()])
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "加载智能报告数据失败");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!selectedTemplateId) {
      setVariables([]);
      setVariableDrafts({});
      return;
    }
    let cancelled = false;
    setLoading(true);
    apiGet<SmartReportTemplateVariableDto[]>(`/api/smart-reports/templates/${selectedTemplateId}/variables`)
      .then((rows) => {
        if (cancelled) return;
        setVariables(rows);
        setVariableDrafts(
          Object.fromEntries(
            rows.map((item) => [
              item.variable_key,
              {
                variable_key: item.variable_key,
                variable_name: item.variable_name,
                variable_type: item.variable_type,
                binding_config: item.binding_config,
                display_order: item.display_order,
              },
            ]),
          ),
        );
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "加载模板变量失败");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [selectedTemplateId]);

  useEffect(() => {
    setParamValues((current) => {
      const next = { ...current };
      for (const item of parameterVariables) {
        const key = paramKeyOf(item);
        if (next[key] === undefined) next[key] = "";
      }
      return next;
    });
    setTextValues((current) => {
      const next = { ...current };
      for (const item of textVariables) {
        const key = textKeyOf(item);
        if (next[key] === undefined) next[key] = "";
      }
      return next;
    });
  }, [variables]);

  const handleUpload = async () => {
    if (!selectedFile) {
      setError("请选择 .docx 模板文件");
      return;
    }
    const code = templateCode.trim() || selectedFile.name.replace(/\.docx$/i, "");
    const name = templateName.trim() || selectedFile.name.replace(/\.docx$/i, "");
    const form = new FormData();
    form.append("file", selectedFile);
    form.append("template_code", code);
    form.append("template_name", name);
    form.append("template_type", "analysis");
    setUploading(true);
    setError("");
    setMessage("");
    try {
      const result = await apiPostForm<SmartReportTemplateCreateResponseDto>("/api/smart-reports/templates", form);
      setMessage(`模板已上传，识别到 ${result.placeholders.length} 个占位符`);
      setSelectedTemplateId(result.template.template_id);
      setSelectedFile(null);
      setTemplateCode("");
      setTemplateName("");
      setTemplateContent("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      await Promise.all([loadTemplates(true), loadInstances()]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "上传模板失败");
    } finally {
      setUploading(false);
    }
  };

  const handleSaveTextTemplate = async () => {
    const code = templateCode.trim();
    const name = templateName.trim();
    const content = templateContent.trim();
    if (!code || !name || !content) {
      setError("请填写模板编码、模板名称和模板内容");
      return;
    }
    setUploading(true);
    setError("");
    setMessage("");
    try {
      const payload: SmartReportTextTemplateCreateDto = {
        template_code: code,
        template_name: name,
        content: templateContent,
        template_type: "analysis",
      };
      const result = await apiPost<SmartReportTemplateCreateResponseDto>("/api/smart-reports/templates/text", payload);
      setMessage(`模板已保存，识别到 ${result.placeholders.length} 个占位符`);
      setSelectedTemplateId(result.template.template_id);
      setTemplateCode("");
      setTemplateName("");
      setTemplateContent("");
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      await Promise.all([loadTemplates(true), loadInstances()]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "保存手工模板失败");
    } finally {
      setUploading(false);
    }
  };

  const updateDraft = (
    variableKey: string,
    patch: Partial<Pick<SmartReportTemplateVariableUpsertDto, "variable_name" | "variable_type">>,
  ) => {
    setVariableDrafts((current) => {
      const previous = current[variableKey];
      if (!previous) return current;
      const variableType = patch.variable_type ?? previous.variable_type ?? "text";
      return {
        ...current,
        [variableKey]: {
          ...previous,
          ...patch,
          binding_config: bindingConfigFor(variableKey, variableType),
        },
      };
    });
  };

  const handleSaveVariables = async () => {
    if (!selectedTemplateId) return;
    setSavingVariables(true);
    setError("");
    setMessage("");
    try {
      const payload = Object.values(variableDrafts).map((item, index) => ({
        ...item,
        display_order: item.display_order ?? index,
        binding_config: bindingConfigFor(item.variable_key, item.variable_type ?? "text"),
      }));
      const rows = await apiPut<SmartReportTemplateVariableDto[]>(
        `/api/smart-reports/templates/${selectedTemplateId}/variables`,
        payload,
      );
      setVariables(rows);
      setMessage("变量配置已保存");
      await loadTemplates(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "保存变量配置失败");
    } finally {
      setSavingVariables(false);
    }
  };

  const handleGenerate = async () => {
    if (!selectedTemplateId || !selectedTemplate) {
      setError("请选择报告模板");
      return;
    }
    setGenerating(true);
    setError("");
    setMessage("");
    try {
      const result = await apiPost<SmartReportGenerateResponseDto>("/api/smart-reports/generate", {
        template_id: selectedTemplateId,
        instance_name: `${selectedTemplate.template_name} ${new Date().toLocaleString()}`,
        parameters: paramValues,
        text_values: textValues,
      });
      setLastGenerated(result);
      setMessage(`报告已生成：${result.output_filename}`);
      await loadInstances();
      await downloadFile(result.download_url, result.output_filename);
    } catch (err) {
      setError(err instanceof Error ? err.message : "生成 Word 报告失败");
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadInstance = async (instance: SmartReportInstanceDto) => {
    await downloadFile(`/api/smart-reports/instances/${instance.instance_id}/download`, `${instance.instance_name}.docx`);
  };

  const handleRefreshInstance = async (instance: SmartReportInstanceDto) => {
    setRefreshingInstanceId(instance.instance_id);
    setError("");
    setMessage("");
    try {
      const result = await apiPost<SmartReportGenerateResponseDto>(
        `/api/smart-reports/instances/${instance.instance_id}/refresh`,
        {},
      );
      setLastGenerated(result);
      setMessage(`报告已刷新：${result.output_filename}`);
      await loadInstances();
      await downloadFile(result.download_url, result.output_filename);
    } catch (err) {
      setError(err instanceof Error ? err.message : "刷新 Word 报告失败");
    } finally {
      setRefreshingInstanceId(null);
    }
  };

  return (
    <div className="h-full flex flex-col p-4 bg-slate-50/40">
      <div className="flex items-center justify-between mb-3 gap-3">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-slate-700" />
          <h3 className="text-sm font-medium text-gray-800">智能分析报告</h3>
          {loading && <Loader2 className="w-3.5 h-3.5 text-blue-500 animate-spin" />}
        </div>
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="搜索模板编码或名称"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="pl-8 pr-3 py-1.5 border border-gray-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 w-64 bg-white"
          />
        </div>
      </div>

      {(error || message) && (
        <div
          className={`mb-3 flex items-center gap-2 border px-3 py-2 text-xs rounded ${
            error ? "border-red-200 bg-red-50 text-red-700" : "border-emerald-200 bg-emerald-50 text-emerald-700"
          }`}
        >
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error || message}</span>
        </div>
      )}

      <div className="grid grid-cols-[minmax(360px,0.9fr)_minmax(520px,1.4fr)] gap-3 min-h-0 flex-1">
        <section className="min-h-0 flex flex-col border border-gray-300 rounded bg-white">
          <div className="border-b border-gray-200 px-3 py-2 flex items-center justify-between">
            <div className="text-xs font-medium text-gray-700">报告模板</div>
            <button
              type="button"
              onClick={() => void loadTemplates(true)}
              className="inline-flex items-center gap-1 px-2 py-1 border border-gray-300 rounded text-xs hover:bg-gray-50"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              刷新
            </button>
          </div>

          <div className="p-3 border-b border-gray-200 grid grid-cols-2 gap-2">
            <div className="col-span-2 grid grid-cols-2 gap-1 bg-gray-100 border border-gray-200 rounded p-1">
              <button
                type="button"
                onClick={() => setTemplateInputMode("upload")}
                className={`px-2 py-1 text-xs rounded ${
                  templateInputMode === "upload" ? "bg-white text-blue-700 shadow-sm" : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                上传 Word
              </button>
              <button
                type="button"
                onClick={() => setTemplateInputMode("text")}
                className={`px-2 py-1 text-xs rounded ${
                  templateInputMode === "text" ? "bg-white text-blue-700 shadow-sm" : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                手工录入
              </button>
            </div>
            <input
              value={templateCode}
              onChange={(e) => setTemplateCode(e.target.value)}
              placeholder="模板编码"
              className="border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <input
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="模板名称"
              className="border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            {templateInputMode === "upload" ? (
              <>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".docx"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] ?? null)}
                  className="col-span-2 text-xs file:mr-2 file:px-2 file:py-1 file:border file:border-gray-300 file:rounded file:bg-white file:text-xs"
                />
                <button
                  type="button"
                  onClick={() => void handleUpload()}
                  disabled={uploading}
                  className="col-span-2 inline-flex justify-center items-center gap-1 px-3 py-1.5 bg-blue-600 text-white rounded text-xs hover:bg-blue-700 disabled:opacity-60"
                >
                  {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                  上传并识别占位符
                </button>
              </>
            ) : (
              <>
                <textarea
                  value={templateContent}
                  onChange={(e) => setTemplateContent(e.target.value)}
                  placeholder={"输入报告模板内容，可使用占位符：\\n{{report_title}}\\n{{param:year}}\\n{{metric:m_budget_actual_gap}}"}
                  className="col-span-2 h-28 border border-gray-300 rounded px-2 py-1.5 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={() => void handleSaveTextTemplate()}
                  disabled={uploading}
                  className="col-span-2 inline-flex justify-center items-center gap-1 px-3 py-1.5 bg-blue-600 text-white rounded text-xs hover:bg-blue-700 disabled:opacity-60"
                >
                  {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  保存为模板
                </button>
              </>
            )}
          </div>

          <div className="flex-1 overflow-auto">
            <table className="w-full text-xs border-collapse">
              <thead className="bg-gray-100 sticky top-0">
                <tr>
                  <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700">模板</th>
                  <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700 w-20">版本</th>
                  <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700 w-20">变量</th>
                </tr>
              </thead>
              <tbody>
                {filteredTemplates.map((item) => (
                  <tr
                    key={item.template_id}
                    onClick={() => setSelectedTemplateId(item.template_id)}
                    className={`cursor-pointer ${selectedTemplateId === item.template_id ? "bg-blue-50" : "hover:bg-gray-50"}`}
                  >
                    <td className="border-b border-gray-200 px-2 py-2">
                      <div className="font-medium text-gray-800">{item.template_name}</div>
                      <div className="text-gray-500 mt-0.5">{item.template_code}</div>
                    </td>
                    <td className="border-b border-gray-200 px-2 py-2 text-gray-700">v{item.version_no}</td>
                    <td className="border-b border-gray-200 px-2 py-2 text-gray-700">{item.variable_count}</td>
                  </tr>
                ))}
                {filteredTemplates.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-3 py-8 text-center text-gray-400">
                      暂无模板
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="min-h-0 flex flex-col gap-3">
          <div className="border border-gray-300 rounded bg-white min-h-0 flex flex-col flex-[1.2]">
            <div className="border-b border-gray-200 px-3 py-2 flex items-center justify-between">
              <div className="text-xs font-medium text-gray-700">
                变量绑定{selectedTemplate ? `：${selectedTemplate.template_name}` : ""}
              </div>
              <button
                type="button"
                onClick={() => void handleSaveVariables()}
                disabled={!selectedTemplateId || savingVariables}
                className="inline-flex items-center gap-1 px-2 py-1 border border-gray-300 rounded text-xs hover:bg-gray-50 disabled:opacity-60"
              >
                {savingVariables ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                保存变量
              </button>
            </div>
            <div className="flex-1 overflow-auto">
              <table className="w-full text-xs border-collapse">
                <thead className="bg-gray-100 sticky top-0">
                  <tr>
                    <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700">占位符</th>
                    <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700">名称</th>
                    <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700 w-28">类型</th>
                  </tr>
                </thead>
                <tbody>
                  {variables.map((item) => {
                    const draft = variableDrafts[item.variable_key] ?? {
                      variable_key: item.variable_key,
                      variable_name: item.variable_name,
                      variable_type: item.variable_type,
                    };
                    return (
                      <tr key={item.variable_id} className="hover:bg-gray-50">
                        <td className="border-b border-gray-200 px-2 py-2 font-mono text-[11px] text-gray-700">
                          {`{{${item.variable_key}}}`}
                        </td>
                        <td className="border-b border-gray-200 px-2 py-1">
                          <input
                            value={draft.variable_name ?? ""}
                            onChange={(e) => updateDraft(item.variable_key, { variable_name: e.target.value })}
                            className="w-full border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </td>
                        <td className="border-b border-gray-200 px-2 py-1">
                          <select
                            value={draft.variable_type ?? item.variable_type}
                            onChange={(e) =>
                              updateDraft(item.variable_key, { variable_type: e.target.value as SmartReportVariableTypeDto })
                            }
                            className="w-full border border-gray-300 rounded px-2 py-1 text-xs bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                          >
                            {VARIABLE_TYPES.map((type) => (
                              <option key={type} value={type}>
                                {VARIABLE_TYPE_LABEL[type]}
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    );
                  })}
                  {variables.length === 0 && (
                    <tr>
                      <td colSpan={3} className="px-3 py-8 text-center text-gray-400">
                        选择或上传模板后显示变量
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-[minmax(320px,1fr)_minmax(320px,1fr)] gap-3 min-h-0 flex-1">
            <div className="border border-gray-300 rounded bg-white min-h-0 flex flex-col">
              <div className="border-b border-gray-200 px-3 py-2 flex items-center justify-between">
                <div className="text-xs font-medium text-gray-700">生成参数</div>
                <button
                  type="button"
                  onClick={() => void handleGenerate()}
                  disabled={!selectedTemplateId || generating}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-600 text-white rounded text-xs hover:bg-emerald-700 disabled:opacity-60"
                >
                  {generating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
                  生成 Word
                </button>
              </div>
              <div className="p-3 overflow-auto space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  {["year", "month", "version_id", "budget_actual"].map((key) => (
                    <label key={key} className="block">
                      <span className="block text-[11px] text-gray-500 mb-1">{key}</span>
                      <input
                        value={paramValues[key] ?? ""}
                        onChange={(e) => setParamValues((current) => ({ ...current, [key]: e.target.value }))}
                        className="w-full border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </label>
                  ))}
                </div>
                {parameterVariables
                  .map(paramKeyOf)
                  .filter((key) => !["year", "month", "version_id", "budget_actual"].includes(key))
                  .map((key) => (
                    <label key={key} className="block">
                      <span className="block text-[11px] text-gray-500 mb-1">{key}</span>
                      <input
                        value={paramValues[key] ?? ""}
                        onChange={(e) => setParamValues((current) => ({ ...current, [key]: e.target.value }))}
                        className="w-full border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </label>
                  ))}
                {textVariables.map((item) => {
                  const key = textKeyOf(item);
                  return (
                    <label key={item.variable_key} className="block">
                      <span className="block text-[11px] text-gray-500 mb-1">{item.variable_name}</span>
                      <input
                        value={textValues[key] ?? ""}
                        onChange={(e) => setTextValues((current) => ({ ...current, [key]: e.target.value }))}
                        className="w-full border border-gray-300 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </label>
                  );
                })}
                {metricVariables.length > 0 && (
                  <div className="border border-gray-200 rounded p-2 bg-gray-50">
                    <div className="text-[11px] text-gray-500 mb-1">本次会计算的指标</div>
                    <div className="flex flex-wrap gap-1">
                      {metricVariables.map((item) => (
                        <span key={item.variable_key} className="px-1.5 py-0.5 rounded border border-gray-300 bg-white text-[11px]">
                          {item.variable_name}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {lastGenerated && (
                  <div className="border border-emerald-200 rounded p-2 bg-emerald-50 text-xs text-emerald-700">
                    最近生成：{lastGenerated.output_filename}
                  </div>
                )}
              </div>
            </div>

            <div className="border border-gray-300 rounded bg-white min-h-0 flex flex-col">
              <div className="border-b border-gray-200 px-3 py-2 text-xs font-medium text-gray-700">报告实例</div>
              <div className="flex-1 overflow-auto">
                <table className="w-full text-xs border-collapse">
                  <thead className="bg-gray-100 sticky top-0">
                    <tr>
                      <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700">实例</th>
                      <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700 w-24">状态</th>
                      <th className="border-b border-gray-300 px-2 py-2 text-left text-gray-700 w-20">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {instances.map((item) => (
                      <tr key={item.instance_id} className="hover:bg-gray-50">
                        <td className="border-b border-gray-200 px-2 py-2">
                          <div className="font-medium text-gray-800">{item.instance_name}</div>
                          <div className="text-gray-500 mt-0.5">生成：{fmtTime(item.last_generated_at ?? item.created_at)}</div>
                          {item.last_refresh_at && <div className="text-gray-500 mt-0.5">刷新：{fmtTime(item.last_refresh_at)}</div>}
                          {item.error_message && <div className="text-red-500 mt-0.5">{item.error_message}</div>}
                        </td>
                        <td className="border-b border-gray-200 px-2 py-2 text-gray-700">{item.generation_status}</td>
                        <td className="border-b border-gray-200 px-2 py-2">
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => void handleRefreshInstance(item)}
                              disabled={refreshingInstanceId === item.instance_id}
                              className="inline-flex items-center justify-center w-7 h-7 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50"
                              title="按原参数刷新"
                            >
                              {refreshingInstanceId === item.instance_id ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <RefreshCw className="w-3.5 h-3.5" />
                              )}
                            </button>
                          <button
                            type="button"
                            onClick={() => void handleDownloadInstance(item)}
                            disabled={item.generation_status !== "success"}
                            className="inline-flex items-center justify-center w-7 h-7 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50"
                            title="下载 Word"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {instances.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-3 py-8 text-center text-gray-400">
                          暂无生成记录
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
